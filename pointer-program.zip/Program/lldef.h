struct ll_node    // C++11 allows default values for members
{
    <type> data;   // contains useful information
    ll_node* next; // the link to the next node
};
