/* File: extern.h */
/* External global variable declarations */
extern int num_calls;
